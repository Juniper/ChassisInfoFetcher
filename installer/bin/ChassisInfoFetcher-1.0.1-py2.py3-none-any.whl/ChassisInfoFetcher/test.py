import curses
from curses.textpad import Textbox, rectangle

def main(stdscr):
    stdscr.addstr(0, 0, "Enter IM message: (hit Ctrl-G to send)")

    editwin = curses.newwin(5,30, 2,1)
    rectangle(stdscr, 1,0, 1+5+1, 1+30+1)
    stdscr.refresh()

    box = Textbox(editwin)

    # Let the user edit until Ctrl-G is struck.
    box.edit()

    # Get resulting contents
    message = box.gather()



    #!/usr/bin/env python

# Script retrieves content of "show chassis hardware | display xml" #
# on all devices managed by Junos Space. Outputs to stdout:         #
#                                                                   #
#       python [this-script-name].pl > output.txt                   #
#                                                                   #
# leoedwards@juniper.net                                            #

from jnpr.space import rest
from lxml import etree

spc=rest.Space(url='https://172.30.200.232', user='super', passwd='Juniper123_') #Apply your credentials here
devices_list = spc.device_management.devices.get()                               #Retrieve list of devices managed by space
for device in devices_list:                                                      #Iterate through devices
    inventory=device.exec_rpc.post(rpcCommand='<get-chassis-inventory></get-chassis-inventory>')    #Send RPC call to each device
    foo=inventory.xpath('netConfReplies/netConfReply/replyMsgData/chassis-inventory')[0]            #Retrieve reply, extract chassis-inventory
    print etree.tostring(foo, pretty_print=True)                                                    #Pretty print xml reply
    