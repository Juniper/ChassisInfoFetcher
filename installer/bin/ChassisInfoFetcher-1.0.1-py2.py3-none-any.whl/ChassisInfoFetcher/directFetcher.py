#!/usr/bin/env python
"""
 ******************************************************************************
 * Copyright (c) 2014  Juniper Networks. All Rights Reserved.
 *
 * YOU MUST ACCEPT THE TERMS OF THIS DISCLAIMER TO USE THIS SOFTWARE
 *
 * JUNIPER IS WILLING TO MAKE THE INCLUDED SCRIPTING SOFTWARE AVAILABLE TO YOU
 * ONLY UPON THE CONDITION THAT YOU ACCEPT ALL OF THE TERMS CONTAINED IN THIS
 * DISCLAIMER. PLEASE READ THE TERMS AND CONDITIONS OF THIS DISCLAIMER
 * CAREFULLY.
 *
 * THE SOFTWARE CONTAINED IN THIS FILE IS PROVIDED "AS IS." JUNIPER MAKES NO
 * WARRANTIES OF ANY KIND WHATSOEVER WITH RESPECT TO SOFTWARE. ALL EXPRESS OR
 * IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY WARRANTY
 * OF NON-INFRINGEMENT OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, ARE HEREBY DISCLAIMED AND EXCLUDED TO THE EXTENT ALLOWED
 * BY APPLICABLE LAW.
 * 
 * IN NO EVENT WILL JUNIPER BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR
 * FOR DIRECT, SPECIAL, INDIRECT, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES
 * HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY ARISING OUT OF THE
 * USE OF OR INABILITY TO USE THE SOFTWARE, EVEN IF JUNIPER HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * 
 ********************************************************************************
 * Project GIT  :  https://git.juniper.net/asmeureanu/ChassisInfoFetcher
 ********************************************************************************
"""

from __future__ import print_function
import base64
import os
import socket
import sys
import time
import traceback
import string
import re
import json

from multiprocessing import Pool
from datetime import date, datetime, timedelta

from jnpr.junos import Device
from jnpr.junos.utils.config import Config
from jnpr.junos.utils.start_shell import StartShell
from jnpr.junos.exception import *
from lxml import etree

import logging
import logging.config


class DirectFetcher:

 
    def __init__(self):
        self.THREADCOUNT=15
        self.jobList=[]
    
    def __call__(self,args):
        return self.job(args)

    # process job 
    def job(self,args):
       
        args=eval(args)
        logging.info("Connecting to: "+args["host"])
        Device.auto_probe = 15
        dev = Device(host=args["host"],port=int(args["port"]),user=args["username"],password=args["password"])
        # open a connection with the device and start a NETCONF session
        try:
            dev.open()
        except Exception as err:
            logging.error("Cannot connect to device ["+args["host"]+"]:")
            return ""
        try:
            dev.bind( cu=Config )
            logging.info("Connected to device ["+args["host"]+"]")
            ss = StartShell(dev)
            ss.open()
            ss.send('cli')  # start CLI process 
            ss.send('show chassis hardware detail | display xml | no-more')    # running show chassis command
            ss.send('exit')  # close the spawned cli process

            logging.info("Waiting for 'show chassis hardware' command reply ["+args["host"]+"]")
            output="".join(ss.wait_for())

            ss.close()  # close shell session
            output="\n".join(output.splitlines()[2:-3]).strip("\n")+"\n\n"  # prepare output by concatenating all lines and kicking out the un needed commands
            
        except Exception as err:
            logging.error("Error parsing command output ["+args["host"]+"]:", err)
            return ""

        logging.info("Done ["+args["host"]+"].") 
        return output
      

    # load and validate intput file return (False,ErrorMessage) if inputs are invalid or (True,SuccessMessage) if they are valid
    def LoadInputFile(self):
        
        hosts_lines= []
        general_settings= []

        

        #### read the device list from input file
        try:
            with open("hosts.csv", "r") as hosts_file:
                hosts_lines = hosts_file.readlines()
        except:
            msg="Loading and Verifying Device List : Unable to read input file 'hosts.csv'."
            logging.error(msg)
            return (False,msg)
        #### read the general settings information
        try:
            with open('conf/directFetcher.conf') as data_file:    
                general_settings = json.load(data_file)
        except:
            msg="Loading and Verifying Device List : Unable to read input or parse file 'directFetcher.conf' responsible for storing general settings."
            logging.error(msg)
            return (False,msg)

        self.THREADCOUNT=int(general_settings["parallelProcesses"])
        
        #### build the in-memory structure
        for host_line in hosts_lines:
            host_line = host_line.strip(' \t\n\r')
            ## Skip empty lines
            if host_line == "" :
                continue;
            ## Skip if line begins with '#''
            if host_line[0] == ord('#'):
                continue;

            host_entry={}
            items=host_line.split(",")
            if len(items) == 1:
                if not type(general_settings["port"]) is  list:
                    general_settings["port"]=[general_settings["port"]]

                for port in general_settings["port"]:
                    host_entry["host"]=items[0]
                    host_entry["username"]=general_settings["username"]
                    host_entry["password"]=general_settings["password"]
                    host_entry["port"]=port
                    self.jobList.append(str(host_entry))


            if len(items) == 4:
                host_entry["host"]=items[0]
                host_entry["username"]=items[1]
                host_entry["password"]=items[2]
                host_entry["port"]=items[3]
                self.jobList.append(str(host_entry))
            
        #print(self.jobList)
        msg="Loading and Verifying Device List : Successful, loaded (%s) hosts!"%str(len(self.jobList))
        logging.info(msg)
        return (True,msg)


    def Run(self):
        p = Pool(self.THREADCOUNT)
        ret=p.map(self,self.jobList)
        success = 0
        failed = 0

        fo = open("output/output.xml", "w")
        for xml in ret:
            if xml!="":   # if process fails he will return an empty string instead of the command reply
                success+=1   
            else:
                failed+=1
            hosts = fo.write(xml)

        fo.close()
        msg="Retriving chassis information from devices : Process finished failed hosts (%s) | success hosts (%s) "%(failed,success)
        logging.info(msg)
        return (True,msg) 


if __name__ == '__main__':
    logging.config.fileConfig('conf/logging.conf')
    df=DirectFetcher()
    df.LoadInputFile()
    # To test single process job  for debugging purposes use the following: 
    #df.job("{'username': 'mkim', 'host': '172.30.77.181', 'password': 'mkim', 'port': '22'}")
    df.Run()
    #df.Run()







